package com.flowersofk.yoursomeplaces.data

data class PlaceData(

    val totalCount: Int,
    val product: List<PlaceProduct>

)